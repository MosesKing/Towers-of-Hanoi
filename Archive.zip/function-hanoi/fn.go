package main

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/crossplane/crossplane-runtime/pkg/errors"
	"github.com/crossplane/function-sdk-go/logging"
	fnv1beta1 "github.com/crossplane/function-sdk-go/proto/v1beta1"
	"github.com/crossplane/function-sdk-go/response"
	"google.golang.org/protobuf/types/known/structpb"
)

type Move struct {
	Disc int    `json:"disc"`
	From string `json:"from"`
	To   string `json:"to"`
}

func generateMoves(n int, from, to, via string, moves *[]Move) {
	if n > 0 {
		generateMoves(n-1, from, via, to, moves)
		*moves = append(*moves, Move{Disc: n, From: from, To: to})
		generateMoves(n-1, via, to, from, moves)
	}
}

type Function struct {
	fnv1beta1.UnimplementedFunctionRunnerServiceServer
	log logging.Logger
}

func (f *Function) RunFunction(ctx context.Context, req *fnv1beta1.RunFunctionRequest) (*fnv1beta1.RunFunctionResponse, error) {
	f.log.Info("Running function", "tag", req.GetMeta().GetTag())
	rsp := response.To(req, response.DefaultTTL)

	if req.Input == nil || req.Input.Fields == nil {
		f.log.Info("Input or input fields are nil")
		return nil, errors.New("input or input fields are nil")
	}

	discsValue, exists := req.Input.Fields["discs"]
	if !exists {
		f.log.Info("Discs field is missing from input")
		return nil, errors.Errorf("discs field is missing from input")
	}

	// Checking and extracting the number value correctly
	discsNum, ok := discsValue.GetKind().(*structpb.Value_NumberValue)
	if !ok {
		f.log.Info("Discs field is not a number")
		return nil, fmt.Errorf("discs field is not a number")
	}
	discs := int(discsNum.NumberValue)
	if discs <= 0 {
		return nil, fmt.Errorf("invalid number of discs: %d", discs)
	}

	var moves []Move
	generateMoves(discs, "A", "C", "B", &moves)

	movesData, err := json.Marshal(moves)
	if err != nil {
		response.Fatal(rsp, errors.Wrap(err, "failed to marshal moves into JSON"))
		return rsp, nil
	}

	response.Normalf(rsp, string(movesData))
	f.log.Info("Tower of Hanoi solution generated", "discs", discs, "moves", string(movesData))

	return rsp, nil
}
